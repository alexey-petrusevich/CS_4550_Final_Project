defmodule ServerWeb.PageView do
  use ServerWeb, :view
end
