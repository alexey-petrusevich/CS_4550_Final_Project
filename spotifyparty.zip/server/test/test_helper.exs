ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Server.Repo, :manual)
